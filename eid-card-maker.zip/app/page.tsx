export default function Home(){
return (
<div style={{padding:'30px',fontFamily:'sans-serif'}}>
<h1>منصة بطاقات عيد الأضحى</h1>
<p>النسخة الأولية تعمل.</p>
<input placeholder="اكتب التهنئة"/>
<br/><br/>
<input placeholder="الاسم"/>
<br/><br/>
<button>تصدير</button>
</div>
)
}